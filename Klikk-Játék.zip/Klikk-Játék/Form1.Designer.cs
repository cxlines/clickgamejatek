﻿namespace Klikk_Játék
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.player1 = new System.Windows.Forms.Panel();
            this.player2 = new System.Windows.Forms.Panel();
            this.player1points = new System.Windows.Forms.Label();
            this.player2points = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // player1
            // 
            this.player1.BackColor = System.Drawing.Color.Aquamarine;
            this.player1.Dock = System.Windows.Forms.DockStyle.Left;
            this.player1.Location = new System.Drawing.Point(0, 0);
            this.player1.Name = "player1";
            this.player1.Size = new System.Drawing.Size(340, 508);
            this.player1.TabIndex = 0;
            this.player1.Click += new System.EventHandler(this.player1_Click);
            // 
            // player2
            // 
            this.player2.BackColor = System.Drawing.Color.Aquamarine;
            this.player2.Dock = System.Windows.Forms.DockStyle.Right;
            this.player2.Location = new System.Drawing.Point(580, 0);
            this.player2.Name = "player2";
            this.player2.Size = new System.Drawing.Size(340, 508);
            this.player2.TabIndex = 1;
            this.player2.Click += new System.EventHandler(this.player2_Click);
            // 
            // player1points
            // 
            this.player1points.AutoSize = true;
            this.player1points.Font = new System.Drawing.Font("Trebuchet MS", 58F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.player1points.Location = new System.Drawing.Point(346, 189);
            this.player1points.Name = "player1points";
            this.player1points.Size = new System.Drawing.Size(103, 121);
            this.player1points.TabIndex = 2;
            this.player1points.Text = "0";
            // 
            // player2points
            // 
            this.player2points.AutoSize = true;
            this.player2points.Font = new System.Drawing.Font("Trebuchet MS", 58F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.player2points.Location = new System.Drawing.Point(471, 189);
            this.player2points.Name = "player2points";
            this.player2points.Size = new System.Drawing.Size(103, 121);
            this.player2points.TabIndex = 3;
            this.player2points.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Trebuchet MS", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(346, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 38);
            this.label1.TabIndex = 4;
            this.label1.Text = "Játékos1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Trebuchet MS", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(440, 461);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(134, 38);
            this.label2.TabIndex = 5;
            this.label2.Text = "Játékos2";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(920, 508);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.player2points);
            this.Controls.Add(this.player1points);
            this.Controls.Add(this.player2);
            this.Controls.Add(this.player1);
            this.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ClickGame: Játék";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel player1;
        private System.Windows.Forms.Panel player2;
        private System.Windows.Forms.Label player1points;
        private System.Windows.Forms.Label player2points;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}

