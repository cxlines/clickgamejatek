﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Klikk_Játék
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int player1kattintas = 0;
        int player2kattintas = 0; //Kattintasok szamanak beallitasa a jatek elejen

        private void player1_Click(object sender, EventArgs e)
        {

            //Optimális megoldás egy függvénnyel való döntés
            //Ha nem nyerünk, tehát nem érjük el a kívánt limitet pl. 30 Kattintás
            //A Program tovább számol. A verseny célja pedig a limit gyorsabb elérése.

            if (player1kattintas > 29)
            {
                MessageBox.Show("Játékos1 Nyert!", "Gratulálok!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                //Miután lenyomtuk a MessageBox OK - gombját
                player1kattintas = 0;
                player2kattintas = 0;
                player1points.Text = "0";
                player2points.Text = "0";
            }
            else {
                player1kattintas++; //Hozzáadunk egyet
                player1points.Text = Convert.ToString(player1kattintas); //Kiírjuk az értéket
            
            }

        }

        private void player2_Click(object sender, EventArgs e)
        {
            if (player2kattintas > 29)
            {
                MessageBox.Show("Játékos2 Nyert!", "Gratulálok!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                //Visszaállítás
                player1kattintas = 0;
                player2kattintas = 0;
                player1points.Text = "0";
                player2points.Text = "0";
            }
            else
            {
                player2kattintas++; //Hozzáadunk egyet
                player2points.Text = Convert.ToString(player1kattintas); //Kiírjuk az értéket

            }

        }
    }
}
